import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { RankingActions } from "./RankingActions";

export function RankItemTop3({
  position,
  name,
  ml,
  goal,
  photo,
  localReactions,
  onPress,
  isMe,
  metaAlcancada,
  onReactionUpdate,
}: any) {
  // Cores das medalhas baseadas no UserProfileModal
  const medalColor =
    position === 1 ? "#FFD700" : position === 2 ? "#C0C0C0" : "#CD7F32";

  const medalEmoji = position === 1 ? "🥇" : position === 2 ? "🥈" : "🥉";

  // Configuração de gradientes (mantendo as cores de teste atuais)
  const config =
    position === 1
      ? { colors: ["#813BE9", "#FFD89B"], badge: "#FDB813" }
      : position === 2
        ? { colors: ["#7737d1", "#4a2285"], badge: "#D1D1D1" }
        : { colors: ["#7737d1", "#4a2285"], badge: "#FFD89B" };

  // Tamanho unificado com o RankItemRegular
  const PHOTO_SIZE = 56;
  const RING_SIZE = 64; // Pouco maior que a foto para o efeito de borda

  return (
    <LinearGradient
      colors={config.colors}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.card}
    >
      <View style={styles.mainRow}>
        {/* Lado Esquerdo: Número da Colocação */}
        <View style={styles.positionNumberContainer}>
          <Text style={styles.positionNumberText}>{position}</Text>
        </View>

        <TouchableOpacity
          style={styles.userClickArea}
          onPress={onPress}
          activeOpacity={0.7}
        >
          {/* Avatar com Medal Ring e Badge unificado */}
          <View style={styles.avatarWrapper}>
            <View
              style={[
                styles.medalRing,
                {
                  borderColor: medalColor,
                  width: RING_SIZE,
                  height: RING_SIZE,
                  borderRadius: RING_SIZE / 2,
                },
              ]}
            >
              <Image
                source={{ uri: photo || "https://i.pravatar.cc/150" }}
                style={{
                  width: PHOTO_SIZE,
                  height: PHOTO_SIZE,
                  borderRadius: PHOTO_SIZE / 2,
                }}
              />
            </View>
            <View style={[styles.medalBadge, { backgroundColor: medalColor }]}>
              <Text style={styles.medalText}>{medalEmoji}</Text>
            </View>
          </View>

          <View style={styles.infoContainer}>
            <Text style={styles.userName}>{name}</Text>
            <View style={styles.statsRow}>
              <Text style={styles.mlValue}>{ml} ml</Text>
              <Text style={styles.mlGoal}> / {goal}ml</Text>
            </View>
          </View>
        </TouchableOpacity>

        <View style={styles.rightBlock}>
          {metaAlcancada && (
            <View style={styles.metaBadge}>
              <Text style={styles.metaText}>Meta!</Text>
            </View>
          )}
          <RankingActions
            isMe={isMe}
            isTop3={true}
            metaAlcancada={metaAlcancada}
            initialReactions={localReactions}
            onReactionUpdate={onReactionUpdate}
          />
        </View>
      </View>

      {localReactions.length > 0 && (
        <View style={styles.reactionsContainer}>
          {localReactions.map((r: any, i: number) => (
            <View key={i} style={styles.reactionBadge}>
              <Text style={styles.reactionEmoji}>{r.emoji}</Text>
              <Text style={styles.reactionCount}>{r.count}</Text>
            </View>
          ))}
        </View>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 24,
    padding: 12,
    marginBottom: 15,
    elevation: 5,
  },
  mainRow: { flexDirection: "row", alignItems: "center" },
  positionNumberContainer: {
    width: 25,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },
  positionNumberText: {
    fontSize: 22,
    fontWeight: "900",
    color: "rgba(255, 255, 255, 0.8)",
    fontStyle: "italic",
  },
  userClickArea: { flexDirection: "row", alignItems: "center", flex: 1 },
  avatarWrapper: {
    position: "relative",
    marginRight: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  medalRing: {
    borderWidth: 3,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
  },
  medalBadge: {
    position: "absolute",
    bottom: -2,
    right: -2,
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "white",
  },
  medalText: { fontSize: 13 },
  infoContainer: { flex: 1 },
  userName: { fontSize: 16, fontWeight: "bold", color: "white" },
  statsRow: { flexDirection: "row", alignItems: "baseline" },
  mlValue: { fontSize: 18, fontWeight: "900", color: "white" },
  mlGoal: { fontSize: 12, color: "rgba(255,255,255,0.7)", fontWeight: "600" },
  rightBlock: { flexDirection: "row", alignItems: "center", gap: 6 },
  metaBadge: {
    backgroundColor: "#2ECC71",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  metaText: { color: "white", fontSize: 10, fontWeight: "bold" },
  reactionsContainer: {
    flexDirection: "row",
    gap: 8,
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.2)",
    flexWrap: "wrap",
  },
  reactionBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.25)",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 4,
  },
  reactionEmoji: { fontSize: 14 },
  reactionCount: { color: "white", fontSize: 13, fontWeight: "bold" },
});
